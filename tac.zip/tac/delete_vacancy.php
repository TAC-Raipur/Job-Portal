<?php
include ("urls.php");
$id= $_REQUEST['id'];
//echo $id;
include("connect.php");
mysqli_query($con,"delete from vacancy_detail where id = '$id'") or die ("query error");
//echo "delete successfully";
//header('Location:'.$host.$show_vacancy);
header("location:show_vacancy.php");
?>
