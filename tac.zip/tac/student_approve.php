<?php 

include ("connect.php");
include ("urls.php");

$id = $_GET['id'];

if($id != ""){
	$approved = $_GET['approved']?0:1;
	$query = "UPDATE registration SET approved = $approved WHERE id = $id";
	$data = mysqli_query($con,$query) or die ("error");	
}

// redirect url
header('Location:'.$host.$show_registration);