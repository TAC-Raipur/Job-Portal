<?php

$host = "http://localhost/tac";
$show_registration = "/tac/show_registration.php";
$delete_course = "/tac/delete_course.php";
$show_course="/tac/show_course.php";
$delete_company = "/tac/delete_company.php";
$show_company = "/tac/show_company.php";
$show_vacancy= "/tac/show_vacancy.php";