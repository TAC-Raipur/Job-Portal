<?php
$username=$_GET['name'];
$email=$_GET['email'];
$mobile=$_GET['contact'];
$language=$_GET['lang'];
$address=$_GET['add'];
echo $username,$email,$mobile,$language;
include("connect.php"); 
echo "done";
$qry = mysqli_query($con,"insert into registration(studentname,emailid,contactnumber,language,address) values('$username','$email','$mobile','$language','$address')") or die ("query error");
echo "successfully insert";
?>

<!---//include("connect.php"); 
//echo "done";
//$qry = "insert into registration(name,email,contact,address,language) values('$username','$email','$mobile','$address','$language')" or die ("query error");
//echo "successfully insert";--->


<!---//if($query){
//	echo "successfully insert";	
//}else{
//	echo("Error description: " . mysqli_error($con));
//}


// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
---->

