<?php
include("connect.php");
$name = $_GET['txtname'];
$place = $_GET['txtplace'];
$address =$_GET['txtaddress'];
$id = $_GET['txtid'];
echo $name,$place,$address,$id ;
$query=mysqli_query($con,"update company_detail set name ='$name',place ='$place',address='$address' where id ='$id'") or die ("error");
//echo "done";

header("location:show_company.php");

?>