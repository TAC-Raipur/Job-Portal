<?php
include("connect.php");
include("urls.php");
$id= $_REQUEST['id'];
//echo $id;

mysqli_query($con,"delete from company_detail where id = '$id'") or die ("query error");
//echo "delete successfully";
//header("location:".$host.$show_company);
header("location:show_company.php");
?>