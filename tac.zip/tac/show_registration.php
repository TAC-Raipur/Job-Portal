
<?php
include ("connect.php");
include("admin_home.php");

$query=mysqli_query($con,"select * from registration ") or die ("error");

?>

<html>
<body>
	<head>
		<title>Show Registration</title>

		  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	</head><br>
	<div class="table-responsive">
	<font color="#006600" size="7px" face="times"><center><thead>Students Records</thead></center></font>
	<table class="table">

	<table class="table table-hover">

  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Email-ID</th>
      <th scope="col">Contacts</th>
      <th scope="col">Courses</th>
       <th scope="col">Address</th>
        <th scope="col">Approve</th>
         <th scope="col">Reject</th>
          <th scope="col">Rejected Message</th>


    </tr>
  </thead>
  <tbody>
<!--  <form method="POST" action="approved.php"> -->

	<?php
     while($row=mysqli_fetch_array($query)) 
     {
	?>
	 
	   <tr>
	      <td><?php echo $row['id']?></td>
	   	  <td><?php echo $row['studentname']?></td>
	   	  <td><?php echo $row['emailid']?></td>
	   	  <td><?php echo $row['contactnumber']?></td>
	   	  <td><?php echo $row['language']?></td>
	   	  <td><?php echo $row['address']?></td>
	   	  <td colspan="0	">
	   	  	<?php if($row['approved'] == 0){?>
		   	  	<?php /*<input type="checkbox" value="<?=$row['id']?>" name="approved[]"> */?>
            <a href="student_approve.php?id=<?=$row['id']?>&approved=<?=$row['approved']?>">Approve</a>
	   	  	<?php }else{ ?>
  	   	  	<a href="student_approve.php?id=<?=$row['id']?>&approved=<?=$row['approved']?>">Unapprove</a>
          <?php } ?>
	   	  </td>

	   	 

	   	 <td>
       
       <?php 
        if($row['rejected'] != 1){
       ?>
       <a href="javascript:void(0)" data-toggle="modal" data-target="#model<?=$row['id']?>">Reject</a>
       <?php 
        }else{
          echo "<div>Already Rejected<br><a href=reject.php?rst=0&id=$row[id]> UnReject </a></div>";
        }
       ?>
       
         <!-- Modal -->
          <div class="modal fade" id="model<?=$row['id']?>" role="dialog">
            <div class="modal-dialog">
              
              <form method="POST" action="reject.php">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                 <h4 class="modal-title">Give Your Comment</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                 
                </div>
                <div class="modal-body">
                  <textarea rows="4" cols="50" name = "message" color="black" placeholder="enter Comment here">
                  </textarea>
                  <input type="hidden" value="<?=$row['id']?>" name="id" />

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    
                    <button type="submit" class="btn btn-default">Submit</button>
                </div>
              </div>
            </form>
              
            </div>
          </div>
          <!-- end modal -->
     
      </td>
          <td><?php 
          if($row['rejected'] == 1)
            echo $row['rejected_msg'];
          else($row['rejected'] == 1)
          ?></td>
     </tr>
     <?php
        } 
        ?>
        
 
        
         </tbody>

       
  </table>
  </div>
  </table>
  
<!--   <center> <button type="submit"  class="btn btn-primary">Submit</button></center><br> -->
<!--   </form> -->
<head>
  <title>reject here</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>
<form method="POST" action="reject.php">
<div class="container">
  
  <!-- Trigger the modal with a button -->
  
  
</div>
<script type="text/javascript" src="js/tac.js"></script>
</body>
</html>
  

