
<?php
include("connect.php");
include("admin_home.php");
$query=mysqli_query($con,"select * from vacancy_detail ") or die ("error");
//echo "done";
?>
<body>
<br>
  <div class="table-responsive">
  <font color="#006600" size="7px" face="times"><center><thead>Edit Vacancies</thead></center></font>
  <table class="table">

  <table class="table table-hover">

  <thead class="thead-dark">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col">Duration</th>
      <th scope="col">Starting Date</th>
      <th scope="col">Ending Date</th>
       <th scope="col">Field</th>
        <th scope="col">Qualification</th>
         <th scope="col">Operation</th>
       

    </tr>
  </thead>
  <tbody>

    <?php
      while($row = mysqli_fetch_array($query))
      {
      	 echo "<tr><form action =update_vacancy.php method=get>";
      	 echo"<td><input type = text name= txttitle value ='".$row['title']."'></td>";
      	 echo"<td><input type = text name= txtdescription value ='".$row['description']."'></td>";
      	 echo"<td><input type = text name= txtduration value ='".$row['duration']."'></td>";
      	 echo"<td><input type = text name= txtstartingdate  value ='".$row['startingdate']."'></td>";
      	 echo"<td><input type = text name= txtclosingdate  value ='".$row['closingdate']."'></td>";
      	 echo"<td><input type = text name= txtfield value ='".$row['field']."'></td>";
           echo"<td><input type = text name= txtqualification value ='".$row['qualification']."'></td>";
      	 
      	 
      	 echo"<input type = hidden name= txtid value ='".$row['id']."'>";
      	 echo "<td><input type =submit value=Submit></td>";
      	 echo "</form> </tr>";
      }

    ?>
</table>
</body>
</html>