
<?php
include ("connect.php");
include ("urls.php");
$msg = $_POST['message'];

$query=mysqli_query($con,"select * from registration ") or die ("error");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 if(count($_POST['message'])){
     $students = $_POST['message'];
      foreach($students as $key => $student){
     $query = "UPDATE registration SET rejected_msg= '$msg' WHERE id = $student";
       $data = mysqli_query($con,$query) or die ("error");
      }
  }
  // redirect url
  //header('Location:'.$host.$show_registration);

}
$id=$_GET["id"];
$rst=$_GET["rst"];
$query=mysqli_query($con,"update registration set rejected=0 where id='$id' ") or die ("error");
header('Location: show_registration.php');

?>
