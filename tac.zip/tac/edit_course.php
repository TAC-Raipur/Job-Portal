<?php
include("admin_home.php")
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
include("connect.php");
$query=mysqli_query($con,"select * from course ") or die ("error");
//echo "done";
?><br>
  <div class="table-responsive">
  <font color="#006600" size="7px" face="times"><center><thead>Edit Course</thead></center></font>
  <table class="table">

  <table class="table table-hover">

  <thead class="thead-dark">
    <tr>
     
      <th scope="col">Name</th>
      <th scope="col">Fees</th>
      <th scope="col">Duration</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>
  <tbody>


    <?php
      while($row = mysqli_fetch_array($query))
      {
      	 echo "<tr><form action =update_course.php method=get>";
      	 echo"<td><input type = text name= txtname value ='".$row['name']."'></td>";
      	 echo"<td><input type = text name= txtfees value ='".$row['fees']."'></td>";
      	 echo"<td><input type = text name= txtduration value ='".$row['duration']."'></td>";
      	 echo"<input type = hidden name= txtid value ='".$row['id']."'>";
      	 echo "<td><input type =submit value=Submit></td>";
      	 echo "</form> </tr>";
      }

    ?>
</table>
</body>
</html>