-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 28, 2018 at 10:43 AM
-- Server version: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tacstudentdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` varchar(50) NOT NULL,
  `adminpass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `adminpass`) VALUES
('id1', '1234'),
('id2', 'pooja');

-- --------------------------------------------------------

--
-- Table structure for table `company_detail`
--

CREATE TABLE `company_detail` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_detail`
--

INSERT INTO `company_detail` (`id`, `name`, `place`, `address`) VALUES
(2, 'tcs', 'bombay', 'bhilai');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `fees` bigint(30) NOT NULL,
  `duration` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `name`, `fees`, `duration`) VALUES
(222, 'c', 100, '2'),
(223, 'android', 10000, '2'),
(224, 'jkhkj', 999, '2'),
(225, 'jkhkj', 999, '2');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `studentname` varchar(100) NOT NULL,
  `emailid` varchar(200) NOT NULL,
  `contactnumber` varchar(30) NOT NULL,
  `language` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `approved` tinyint(4) NOT NULL DEFAULT '0',
  `rejected` tinyint(4) NOT NULL DEFAULT '0',
  `rejected_msg` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `studentname`, `emailid`, `contactnumber`, `language`, `address`, `approved`, `rejected`, `rejected_msg`) VALUES
(1, 'shweta', 'shwetarai25051999@gmail.com', '9993360064', 'php', 'bhilai', 1, 0, ''),
(2, 'pooja', 'pooja@gmail.com', '7509405921', 'python', 'powerhouse', 1, 0, ''),
(3, 'sahadev sr', 'sahadev@gmail.com', '999225255', 'ruby', 'kursipar', 0, 0, ''),
(4, 'shreya', 'shreya@gmail.com', '7506936825', 'java', 'sector1', 0, 0, ''),
(5, 'pri', 'pri@gmail.com', '9996631254', 'android', 'raipur', 1, 0, ''),
(6, 'poonam', 'poonam@gmail.com', '5253636142', 'php', 'sejbahar', 1, 0, ''),
(7, 'sahadev', 'sahadev007@hotmail.com', '9876543210', 'hindi', 'asdnjkasd', 1, 0, ''),
(8, '', '', '', '', '', 0, 0, '\r\nyou doesnt pay fees'),
(9, 'sahadev', 'sahadev@gmail.com', '999663654', 'python', 'raipur', 0, 0, 'you doesnot pay fees'),
(10, 'sahadev sr', 'sahadev007@hotmail.com', '7509405921', 'telgu uriya', 'kursipar', 0, 0, NULL),
(11, 'sahadev sr', 'sahadev007@hotmail.com', '7509405921', 'telgu uriya', 'kursipar', 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vacancy_detail`
--

CREATE TABLE `vacancy_detail` (
  `id` bigint(20) NOT NULL,
  `company_id` bigint(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `startingdate` date NOT NULL,
  `closingdate` date NOT NULL,
  `field` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_detail`
--
ALTER TABLE `company_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vacancy_detail`
--
ALTER TABLE `vacancy_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company_detail`
--
ALTER TABLE `company_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `vacancy_detail`
--
ALTER TABLE `vacancy_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
