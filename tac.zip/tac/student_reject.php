<?php 

include ("connect.php");
include ("urls.php");

$id = $_GET['id'];

if($id != ""){
	$rejected = $_GET['rejected']?0:1;
	$query = "UPDATE registration SET rejected = $rejected WHERE id = $id";
	$data = mysqli_query($con,$query) or die ("error");	
}

// redirect url
header('Location:'.$host.$show_registration);