<?php
session_start();
include("connect.php");
$id=$_REQUEST['txtid'];
$pass=$_REQUEST['txtpass'];
$query="select * from admin_login where id='$id'" or die ("error");
//echo $query;
$rsAdmin=mysqli_query($con,$query)or die("error qquery");
//8echo "all ok";
$num=mysqli_num_rows($rsAdmin);
//echo $num;
if($num==0)
{

echo "your id is wrong ! please try again!!";

}
else
{
//echo "skjcsdkjc";
//$apass=$arrayFetch($rsAdmin);
	$rw=mysqli_fetch_row($rsAdmin);
//echo $rw[1];
if($rw['1']==$pass)
{

	$_SESSION['id']=$rw['id'];
	//echo "you have suceessfully Login..";
	header("location:admin_home.php");
}
else
{

	echo "your password is wrong! please try again!!";
}
}


?>
