
<?php
include ("connect.php");
include("admin_home.php");
$query=mysqli_query($con,"select * from vacancy_detail ") or die ("error");
?> 

<html>
<body><br>
	<div class="table-responsive">
	<font color="#006600" size="7px" face="times"><center><thead>Vacancies Details</thead></center></font>
	<table class="table">

	<table class="table table-hover">

  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col">Duration</th>
      <th scope="col">Starting Date</th>
      <th scope="col">Ending Date</th>
       <th scope="col">Work Field</th>

        <th scope="col">Qualification</th>
         <th scope="col">Delete Vacancy</th>
          <th scope="col">Edit Vacancy</th>


    </tr>
  </thead>
  <tbody>
	<?php
     while($row=mysqli_fetch_array($query)) 
     {
     	
	?>

	   <tr>
	   	  <td><?php echo $id= $row['id']?></td>
	   	  <td><?php echo $row['title']?></td>
	   	  <td><?php echo $row['description']?></td>
	   	  <td><?php echo $row['duration']?></td>
	   	   <td><?php echo $row['startingdate']?></td>
	   	   <td><?php echo $row['closingdate']?></td>
	   	   <td><?php echo $row['field']?></td>
	   	    <td><?php echo $row['qualification']?></td>
	   	    
	   	  
	   	  
	   	  <td><a href="delete_vacancy.php?id=<?=$id?>">delete</a></td>
	   	  <td><a href="edit_vacancy.php?id = <?=$id?>">edit</a></td>


	   </tr>
	   <?php
	      }	
        ?>
        </tbody>
	</table>
</body>
</html>

