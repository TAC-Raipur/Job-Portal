<?php

$con=mysqli_connect("localhost","root","2904","tacstudentdatabase") or die("no connection");
?>