<?php
include("connect.php"); 
//echo "done";
include("urls.php");
$name=$_GET['txtname'];
$fees=$_GET['txtfees'];
$duration=$_GET['txtduration'];
//echo $id,$name,$fees,$duration;


$qry = mysqli_query($con,"insert into course(name ,fees,duration) values('$name',$fees,'$duration')") or die ("query error");
//echo "successfully insert";
header("location:show_course.php");
//header('location:'.$host.$show_course);
?>