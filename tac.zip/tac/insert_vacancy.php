<?php
$title=$_GET['txttitle'];
$description=$_GET['txtdescription'];
$duration=$_GET['txtduration'];
$startingdate=$_GET['txtstartingdate'];
$closingdate=$_GET['txtclosingdate'];
$field=$_GET['txtfield'];
//$qualification=$_GET['txtqualification'];
echo $title,$description,$duration,$startingdate,$closingdate,$field;
include("connect.php"); 
echo "done";
$qry = mysqli_query($con,"insert into vacancy_detail(title,description,duration,startingdate,closingdate,field) values('$title','$description','$duration','$startingdate','$closingdate','$field')") or die ("query error");
echo "successfully insert";
?>

