<!DOCTYPE html>
<html>
<head>
	<title>tac</title>
</head>
<body >
<form method="GET" action="data.php">
<input type="text" name="name" placeholder="enter the name"><br>
<input type="email" name="email" placeholder="enter the email id"><br>
<input type="text" name="contact" placeholder="enter the contact"><br>
<input type="text" name="lang" placeholder="enter the language "><br>
<input type="text" name="add" placeholder="enter the address"><br>
<input type="submit" value="submit">
</form>
</body>
</html>