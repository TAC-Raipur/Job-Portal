<?php

include("connect.php");
include ("urls.php");
$title = $_GET['txttitle'];
$description = $_GET['txtdescription'];
$duration =$_GET['txtduration'];
$startingdate =$_GET['txtstartingdate'];
$closingdate =$_GET['txtclosingdate'];
$field =$_GET['txtfield'];
$id = $_GET['txtid'];
//echo $title,$description,$duration,$startingdate,$closingdate,$field;
$query=mysqli_query($con,"update vacancy_detail set title='$title',description='$description',duration='$duration ',startingdate='$startingdate',closingdate='$closingdate',field ='$field' where id ='$id'") or die ("error");
//echo "done";

header("location:show_vacancy.php");

?>