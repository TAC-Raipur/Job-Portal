<?php
include("admin_home.php");
?>

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<style> 
textarea {
    width: 100%;
    height: 150px;
    padding: 6px 10px;
    box-sizing: border-box;
   
    border-radius: 4px;
   
     background: linear-gradient(to top, rgb(23,195,17), rgb(17,145,13));
    font-size: 16px;
    resize: none;
}
</style>
<!-- //web font -->
</head>
<body>
	<!-- main -->
	<div class="main-w3layouts wrapper">
		<h1>Add Company</h1>
		<div class="main-agileinfo">
			<div class="agileits-top"> 
				<form action="insert_company.php" method="GET"> 
					<input type="hidden" name="txtid">
					<input class="text" type="text" name="txtname" placeholder="enter company name" required=""><br>
					<input class="text" type="text" name="txtplace" placeholder="enter place" required=""><br>
					<input class="text" type="text" name="txtaddress" placeholder="enter address" required=""><br>
					
					<div class="wthree-text">  
						
						<div class="clear"> </div>
					</div>   
					<input type="submit" value="ADD">
				</form>
				
			</div>	 
		</div>	
		<!-- copyright -->
		<div class="w3copyright-agile">
			<p>TAC| Raipur ©  All rights reserved <a href="http://w3layouts.com/" target="_blank"></a></p>
		</div>
		<!-- //copyright -->
		<ul class="w3lsg-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>	
	<!-- //main --> 
</body>
</html>