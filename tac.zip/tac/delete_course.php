<?php
$id= $_REQUEST['id'];
//echo $id;
include("connect.php");
mysqli_query($con,"delete from course where id = '$id'") or die ("query error");
//echo "delete successfully";
header("Location:show_course.php");
?>