<?php
include("connect.php");
echo "done"; 
$name=$_GET['txtname'];
$place=$_GET['txtplace'];
$address=$_GET['txtaddress'];
echo $name,$place,$address;


$qry = mysqli_query($con,"insert into company_detail(name,place,address) values('$name','$place','$address')") or die ("query error");
echo "successfully insert";
?>