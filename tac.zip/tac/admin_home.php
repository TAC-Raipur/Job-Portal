<!DOCTYPE html>
<html lang="en">

<head>
	<title>TAC</title>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Exertion Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta Tags -->
	<!-- Style-sheets -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
	<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/fontawesome-all.css" rel="stylesheet">
	<!--// Style-sheets -->
		<link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
	<!--web-fonts-->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800" rel="stylesheet">
	<!--//web-fonts-->
</head>

<body>
	<!-- banner -->

		<!-- header -->
		<header>
		<nav class="navbar navbar-expand-lg navbar-light">
		<div class="container">
		<img src="images/logo.png" height="60px">
			<a class="navbar-brand" href="admin_home.php">TAC|Raipur</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
			    aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a class="nav-link" href="admin_home.php">Home
							<span class="sr-only">(current)</span>
						</a>
					</li>
					
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
						    aria-expanded="false">
							Student 
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
							<a class="dropdown-item text-center" href="show_registration.php">Student Details</a>
							<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
						    aria-expanded="false">
							Skills/Courses
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
							<a class="dropdown-item text-center" href="show_course.php">View Course</a>
							<a class="dropdown-item text-center" href="add_course.php">Add Course</a>
							<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
						    aria-expanded="false">
							Company
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
							<a class="dropdown-item text-center" href="show_company.php">Company Details</a>
										<a class="dropdown-item text-center" href="add_company.php">Add Company</a>
							<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
						    aria-expanded="false">
							Vacancy
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
							
							<a class="dropdown-item text-center" href="show_vacancy.php">Vacancies Details</a>
							<a class="dropdown-item text-center" href="add_vacancy.php">Add Vacancies</a>
									
		
						</div>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Notifications</a>
					</li>
	<li class="nav-item">
						<a class="nav-link" href="admin_logout.php">Logout</a>
					</li>
				</ul>
				
				</form>
			</div>
			</div>
		</nav>
		
		</header>
		
	<!-- //copyright -->

    <!-- Required common Js -->
     <script src="js/jquery.min.js"></script>
    <!-- //Required common Js -->
	<!-- Responsiveslides -->
	<script src="js/responsiveslides.min.js"></script>
	
	<!-- start-smoth-scrolling -->
	<!-- //here ends scrolling icon -->
	<!-- Js for bootstrap working-->
	<script src="js/bootstrap.min.js"></script>
	<!-- //Js for bootstrap working -->
</body>

</html>
