<?php
include("connect.php");
$name = $_GET['txtname'];
$fees = $_GET['txtfees'];
$duration =$_GET['txtduration'];
$id = $_GET['txtid'];
echo $name,$fees,$duration,$id ;
$query=mysqli_query($con,"update course set name ='$name',fees ='$fees',duration='$duration' where id ='$id'") or die ("error");
//echo "done";

header("location:show_course.php");

?>