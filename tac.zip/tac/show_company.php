
<?php
include ("connect.php");
include("admin_home.php");
$query=mysqli_query($con,"select * from company_detail ") or die ("error");
?> 

<html>
<body><br>
	<div class="table-responsive">
	<font color="#006600" size="7px" face="times"><center><thead>Company Details</thead></center></font>
	<table class="table">

	<table class="table table-hover">

  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Place</th>
      <th scope="col">Address</th>
      <th scope="col">Delete Company</th>
       <th scope="col">Edit Company</th>
       


    </tr>
  </thead>
  <tbody>
	<?php
     while($row=mysqli_fetch_array($query)) 
     {
     	
	?>

	   <tr>
	   	  <td><?php echo $id= $row['id']?></td>
	   	  <td><?php echo $row['name']?></td>
	   	  <td><?php echo $row['place']?></td>
	   	  <td><?php echo $row['address']?></td>
	   	  <td><a href="delete_company.php?id=<?=$id?>">delete</a></td>
	   	  <td><a href="edit_company.php?id = <?=$id?>">edit</a></td>


	   </tr>
	   <?php
	      }	
        ?>
	</table>
</body>
</html>

