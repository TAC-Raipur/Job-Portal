<?php
include("admin_home.php")
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<?php
include("connect.php");
$var=$_REQUEST['id'];
echo $var;
$query=mysqli_query($con,"select * from company_detail") or die ("error");

//echo "done";
?><br>
  <div class="table-responsive">
  <font color="#006600" size="7px" face="times"><center><thead>Edit Course</thead></center></font>
  <table class="table">

  <table class="table table-hover">

  <thead class="thead-dark">
    <tr>
     
      <th scope="col">Name</th>
      <th scope="col">Place</th>
      <th scope="col">Adress</th>
      <th scope="col">Operation</th>
     
    </tr>
  </thead>
  <tbody>

    <?php
      while($row = mysqli_fetch_array($query))
      {
         echo "<tr><form action =update_company.php method=get>";
         echo"<td><input type = text name= txtname value ='".$row['name']."'></td>";
         echo"<td><input type = text name= txtplace value ='".$row['place']."'></td>";
         echo"<td><input type = text name= txtaddress value ='".$row['address']."'></td>";
         echo"<input type = hidden name= txtid value ='".$row['id']."'>";
         echo "<td><input type =submit value=Submit></td>";
         echo "</form> </tr>";
      }

    ?>
</table>
</body>
</html>
