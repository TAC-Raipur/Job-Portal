<?php
include("admin_home.php");
?>

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<style> 
textarea {
    width: 100%;
    height: 150px;
    padding: 6px 10px;
    box-sizing: border-box;
   
    border-radius: 4px;
   
     background: linear-gradient(to top, rgb(23,195,17), rgb(17,145,13));
    font-size: 16px;
    resize: none;
}
</style>
<!-- //web font -->
</head>
<body>
	<!-- main -->
	<div class="main-w3layouts wrapper">
		<h1>Add Vacancy</h1>
		<div class="main-agileinfo">
			<div class="agileits-top"> 
				<form action="insert_vacancy.php" method="GET"> 
					<input type ="hidden" name="txtid">
					<input class="text" type="text" name="txttitle" placeholder="enter vacancy name" required=""><br>
					<input class="text" type="text" name="txtdescription" placeholder="enter description" required=""><br>
					<input class="text" type="text" name="txtduration" placeholder="enter duration" required=""><br><font color="#fff">Starting Date:
					<input class="text" type="date" name="txtstartingdate" placeholder="enter startingdate" required=""><br><br>Ending Date:
					<input class="text" type="date" name="txtclosingdate" placeholder="enter closing date" required=""><br><br></font>
					<input class="text" type="text" name="txtfield" placeholder="enter field which you required" required=""><br>
					 <font color="#fff">SELECT QUALIFICATION:<div class="checkbox"><br>
 						 <label><input type="checkbox"   name = "txtqualification[]" value="">10th</label>
					</div>
					<div class="checkbox">
 						 <label><input type="checkbox" name = "txtqualification[]" value="">12th</label>
						</div>
					<div class="checkbox">
 							 <label><input type="checkbox" name = "txtqualification[]">diploma</label></font>
					</div>  
					<div class="clear"> </div>
					</div>   
					<input type="submit" value="ADD">
				</form>
				
			</div>	 
		</div>	
		
	
</body>
</html>