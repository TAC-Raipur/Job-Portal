
<?php

include("admin_home.php");
include ("connect.php");
//echo "done";
$query=mysqli_query($con,"select * from course ") or die ("error");
?> 

<html>
<body><br>
	<div class="table-responsive">
	<font color="#006600" size="7px" face="times"><center><thead>Course Details</thead></center></font>
	<table class="table">

	<table class="table table-hover">

  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Fees</th>
      <th scope="col">Duration</th>
      <th scope="col">Delete Course</th>
       <th scope="col">Edit Course</th>
       


    </tr>
  </thead>
  <tbody>
	
	</tr>
	<?php
     while($row=mysqli_fetch_array($query)) 
     {
     	
	?>

	   <tr>
	   	  <td><?php echo $id= $row['id']?></td>
	   	  <td><?php echo $row['name']?></td>
	   	  <td><?php echo $row['fees']?></td>
	   	  <td><?php echo $row['duration']?></td>
	   	  <td><a href="delete_course.php?id=<?=$id?>">Delete</a></td>
	   	  <td><a href="edit_course.php?id = <?=$id?>">Edit </a></td>


	   </tr>
	   <?php
	      }	
        ?>
        </tbody>
	</table>

</body>
</html>

